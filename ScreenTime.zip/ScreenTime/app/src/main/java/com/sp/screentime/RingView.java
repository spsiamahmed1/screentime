package com.sp.screentime;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

public class RingView extends View {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint prog = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private float shown = 0f;
    private ValueAnimator anim;

    public RingView(Context context) {
        super(context);
        init();
    }

    public RingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        track.setStyle(Paint.Style.STROKE);
        track.setColor(Color.parseColor("#33FFFFFF"));
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        prog.setStyle(Paint.Style.STROKE);
        prog.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setProgress(float target) {
        if (anim != null) {
            anim.cancel();
        }
        anim = ValueAnimator.ofFloat(shown, target);
        anim.setDuration(900);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                shown = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float size = Math.min(w, h);
        float stroke = size * 0.085f;
        float pad = stroke * 1.2f;
        float left = (w - size) / 2f + pad;
        float top = (h - size) / 2f + pad;
        rect.set(left, top, left + size - 2 * pad, top + size - 2 * pad);

        track.setStrokeWidth(stroke);
        canvas.drawArc(rect, 0, 360, false, track);

        if (shown <= 0f) {
            return;
        }
        float sweep = 360f * Math.min(shown, 1f);
        if (sweep < 4f) {
            sweep = 4f;
        }

        int color;
        if (shown < 0.7f) {
            color = Color.parseColor("#00E5FF");
        } else if (shown < 1f) {
            color = Color.parseColor("#FFB347");
        } else {
            color = Color.parseColor("#FF4E88");
        }

        glow.setColor(color);
        glow.setAlpha(55);
        glow.setStrokeWidth(stroke * 1.9f);
        canvas.drawArc(rect, -90, sweep, false, glow);

        prog.setColor(color);
        prog.setStrokeWidth(stroke);
        canvas.drawArc(rect, -90, sweep, false, prog);
    }
}
