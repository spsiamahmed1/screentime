package com.sp.screentime;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    private static final String PREFS = "st_prefs";
    private static final String KEY_GOAL = "goal_min";

    private View permCard;
    private View mainContent;
    private RingView ring;
    private TextView tvDate;
    private TextView tvTotal;
    private TextView tvSub;
    private TextView tvStatus;
    private TextView tvGoal;
    private TextView tvAvg;
    private BarChartView chart;
    private LinearLayout appsContainer;

    private int goalMin = 240;
    private long todayTotal = 0;
    private boolean loading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        setContentView(R.layout.activity_main);

        permCard = findViewById(R.id.permCard);
        mainContent = findViewById(R.id.mainContent);
        ring = findViewById(R.id.ring);
        tvDate = findViewById(R.id.tvDate);
        tvTotal = findViewById(R.id.tvTotal);
        tvSub = findViewById(R.id.tvSub);
        tvStatus = findViewById(R.id.tvStatus);
        tvGoal = findViewById(R.id.tvGoal);
        tvAvg = findViewById(R.id.tvAvg);
        chart = findViewById(R.id.chart);
        appsContainer = findViewById(R.id.appsContainer);

        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        goalMin = sp.getInt(KEY_GOAL, 240);
        tvGoal.setText(Fmt.duration(goalMin * 60000L));
    }

    @Override
    protected void onResume() {
        super.onResume();
        tvDate.setText(Fmt.dateLong(Calendar.getInstance()));
        if (UsageHelper.hasPermission(this)) {
            permCard.setVisibility(View.GONE);
            mainContent.setVisibility(View.VISIBLE);
            loadData();
        } else {
            permCard.setVisibility(View.VISIBLE);
            mainContent.setVisibility(View.GONE);
        }
    }

    public void onGrant(View v) {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        if (Build.VERSION.SDK_INT >= 29) {
            intent.setData(Uri.parse("package:" + getPackageName()));
        }
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            } catch (ActivityNotFoundException ignored) {
            }
        }
    }

    public void onGoalMinus(View v) {
        changeGoal(-30);
    }

    public void onGoalPlus(View v) {
        changeGoal(30);
    }

    private void changeGoal(int delta) {
        goalMin = Math.max(30, Math.min(960, goalMin + delta));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_GOAL, goalMin).apply();
        renderSummary();
    }

    private void loadData() {
        if (loading) {
            return;
        }
        loading = true;
        final android.content.Context ctx = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final long[] week = new long[7];
                final String[] labels = new String[7];
                Map<String, Long> todayMap = null;
                try {
                    Calendar now = Calendar.getInstance();
                    for (int i = 6; i >= 0; i--) {
                        Calendar c = (Calendar) now.clone();
                        c.add(Calendar.DAY_OF_YEAR, -i);
                        c.set(Calendar.HOUR_OF_DAY, 0);
                        c.set(Calendar.MINUTE, 0);
                        c.set(Calendar.SECOND, 0);
                        c.set(Calendar.MILLISECOND, 0);
                        long s = c.getTimeInMillis();
                        long e = (i == 0) ? System.currentTimeMillis() : s + 86400000L;
                        Map<String, Long> m = UsageHelper.usage(ctx, s, e);
                        long sum = 0;
                        for (long v : m.values()) {
                            sum += v;
                        }
                        week[6 - i] = sum;
                        labels[6 - i] = Fmt.dayShort(c.get(Calendar.DAY_OF_WEEK));
                        if (i == 0) {
                            todayMap = m;
                        }
                    }
                } catch (Exception ex) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loading = false;
                        }
                    });
                    return;
                }
                final Map<String, Long> finalToday = todayMap;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        render(week, labels, finalToday);
                        loading = false;
                    }
                });
            }
        }).start();
    }

    private void render(long[] week, String[] labels, Map<String, Long> todayMap) {
        todayTotal = week[6];
        long sum = 0;
        for (long v : week) {
            sum += v;
        }
        tvAvg.setText("\u0997\u09A1\u09BC " + Fmt.duration(sum / 7));
        chart.setData(week, labels, goalMin * 60000L);
        renderApps(todayMap);
        renderSummary();
    }

    private void renderSummary() {
        long goalMs = goalMin * 60000L;
        float ratio = goalMs > 0 ? (float) todayTotal / (float) goalMs : 0f;
        ring.setProgress(ratio);
        tvTotal.setText(Fmt.duration(todayTotal));
        tvSub.setText("\u09B2\u0995\u09CD\u09B7\u09CD\u09AF\u09C7\u09B0 " + Fmt.percent(Math.round(ratio * 100)));
        tvGoal.setText(Fmt.duration(goalMs));
        chart.setGoal(goalMs);
        if (todayTotal >= goalMs) {
            tvStatus.setText("\u0986\u099C\u0995\u09C7\u09B0 \u09B2\u0995\u09CD\u09B7\u09CD\u09AF \u09AA\u09BE\u09B0 \u09B9\u09AF\u09BC\u09C7 \u0997\u09C7\u099B\u09C7, \u098F\u0995\u099F\u09C1 \u09AC\u09BF\u09B0\u09A4\u09BF \u09A8\u09BF\u09A8");
            tvStatus.setTextColor(Color.parseColor("#FF8FB1"));
        } else {
            tvStatus.setText("\u09B2\u0995\u09CD\u09B7\u09CD\u09AF\u09C7 \u09AA\u09CC\u0981\u099B\u09BE\u09A4\u09C7 \u0986\u09B0 " + Fmt.duration(goalMs - todayTotal) + " \u09AC\u09BE\u0995\u09BF");
            tvStatus.setTextColor(Color.parseColor("#CCFFFFFF"));
        }
    }

    private void renderApps(Map<String, Long> map) {
        appsContainer.removeAllViews();
        List<Map.Entry<String, Long>> list = new ArrayList<>();
        if (map != null) {
            for (Map.Entry<String, Long> en : map.entrySet()) {
                if (en.getValue() >= 60000L) {
                    list.add(en);
                }
            }
        }
        Collections.sort(list, new Comparator<Map.Entry<String, Long>>() {
            @Override
            public int compare(Map.Entry<String, Long> a, Map.Entry<String, Long> b) {
                return Long.compare(b.getValue(), a.getValue());
            }
        });

        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("\u0986\u099C \u098F\u0996\u09A8\u09CB \u0995\u09CB\u09A8\u09CB \u0985\u09CD\u09AF\u09BE\u09AA \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0\u09C7\u09B0 \u09A4\u09A5\u09CD\u09AF \u09A8\u09C7\u0987");
            empty.setTextColor(Color.parseColor("#B3FFFFFF"));
            empty.setTextSize(15);
            empty.setPadding(0, 16, 0, 8);
            appsContainer.addView(empty);
            return;
        }

        PackageManager pm = getPackageManager();
        long max = list.get(0).getValue();
        int count = Math.min(list.size(), 12);
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 0; i < count; i++) {
            Map.Entry<String, Long> en = list.get(i);
            View row = inflater.inflate(R.layout.item_app, appsContainer, false);
            ImageView icon = row.findViewById(R.id.ivIcon);
            TextView name = row.findViewById(R.id.tvName);
            TextView time = row.findViewById(R.id.tvTime);
            View fill = row.findViewById(R.id.barFill);

            String pkg = en.getKey();
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                name.setText(pm.getApplicationLabel(ai));
                icon.setImageDrawable(pm.getApplicationIcon(ai));
            } catch (PackageManager.NameNotFoundException e) {
                name.setText(pkg);
            }
            time.setText(Fmt.duration(en.getValue()));

            float pct = 100f * en.getValue() / (float) max;
            if (pct < 3f) {
                pct = 3f;
            }
            fill.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, pct));
            appsContainer.addView(row);
        }
    }
}
