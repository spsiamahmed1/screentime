package com.sp.screentime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

public class BarChartView extends View {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint today = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valueText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dayText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goalLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private long[] values = new long[0];
    private String[] labels = new String[0];
    private long goal = 0;
    private float density = 1f;

    public BarChartView(Context context) {
        super(context);
        init();
    }

    public BarChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.parseColor("#55FFFFFF"));

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(density);
        stroke.setColor(Color.parseColor("#88FFFFFF"));

        today.setStyle(Paint.Style.FILL);

        valueText.setColor(Color.parseColor("#E6FFFFFF"));
        valueText.setTextAlign(Paint.Align.CENTER);
        valueText.setTextSize(10 * density);

        dayText.setColor(Color.parseColor("#B3FFFFFF"));
        dayText.setTextAlign(Paint.Align.CENTER);
        dayText.setTextSize(12 * density);

        goalLine.setStyle(Paint.Style.STROKE);
        goalLine.setStrokeWidth(1.5f * density);
        goalLine.setColor(Color.parseColor("#CCFFB347"));
        goalLine.setPathEffect(new DashPathEffect(new float[]{10 * density, 6 * density}, 0));
    }

    public void setData(long[] v, String[] l, long goalMs) {
        values = v;
        labels = l;
        goal = goalMs;
        invalidate();
    }

    public void setGoal(long goalMs) {
        goal = goalMs;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int n = values.length;
        if (n == 0) {
            return;
        }
        float w = getWidth();
        float h = getHeight();
        float top = 22 * density;
        float bottom = 26 * density;
        float chartH = h - top - bottom;

        long max = goal;
        for (long v : values) {
            if (v > max) {
                max = v;
            }
        }
        max = (long) (max * 1.1);
        if (max <= 0) {
            max = 1;
        }

        float slot = w / n;
        float bw = slot * 0.46f;
        float radius = 8 * density;
        float baseY = top + chartH;

        for (int i = 0; i < n; i++) {
            float cx = slot * i + slot / 2f;
            float bh = chartH * ((float) values[i] / (float) max);
            if (values[i] > 0 && bh < 4 * density) {
                bh = 4 * density;
            }
            rect.set(cx - bw / 2f, baseY - bh, cx + bw / 2f, baseY);

            if (i == n - 1) {
                today.setShader(new LinearGradient(0, rect.top, 0, rect.bottom,
                        Color.parseColor("#00E5FF"), Color.parseColor("#B388FF"),
                        Shader.TileMode.CLAMP));
                canvas.drawRoundRect(rect, radius, radius, today);
            } else {
                canvas.drawRoundRect(rect, radius, radius, fill);
                canvas.drawRoundRect(rect, radius, radius, stroke);
            }

            canvas.drawText(Fmt.hoursShort(values[i]), cx, rect.top - 6 * density, valueText);
            if (i < labels.length) {
                canvas.drawText(labels[i], cx, h - 7 * density, dayText);
            }
        }

        if (goal > 0) {
            float gy = baseY - chartH * ((float) goal / (float) max);
            canvas.drawLine(0, gy, w, gy, goalLine);
        }
    }
}
