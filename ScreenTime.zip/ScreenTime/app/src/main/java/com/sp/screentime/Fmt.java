package com.sp.screentime;

import java.util.Calendar;
import java.util.Locale;

final class Fmt {

    private static final String[] DAY_SHORT = {
            "\u09B0\u09AC\u09BF", "\u09B8\u09CB\u09AE", "\u09AE\u0999\u09CD\u0997\u09B2", "\u09AC\u09C1\u09A7", "\u09AC\u09C3\u09B9", "\u09B6\u09C1\u0995\u09CD\u09B0", "\u09B6\u09A8\u09BF"};
    private static final String[] DAY_LONG = {
            "\u09B0\u09AC\u09BF\u09AC\u09BE\u09B0", "\u09B8\u09CB\u09AE\u09AC\u09BE\u09B0", "\u09AE\u0999\u09CD\u0997\u09B2\u09AC\u09BE\u09B0", "\u09AC\u09C1\u09A7\u09AC\u09BE\u09B0", "\u09AC\u09C3\u09B9\u09B8\u09CD\u09AA\u09A4\u09BF\u09AC\u09BE\u09B0", "\u09B6\u09C1\u0995\u09CD\u09B0\u09AC\u09BE\u09B0", "\u09B6\u09A8\u09BF\u09AC\u09BE\u09B0"};
    private static final String[] MONTHS = {
            "\u099C\u09BE\u09A8\u09C1\u09AF\u09BC\u09BE\u09B0\u09BF", "\u09AB\u09C7\u09AC\u09CD\u09B0\u09C1\u09AF\u09BC\u09BE\u09B0\u09BF", "\u09AE\u09BE\u09B0\u09CD\u099A", "\u098F\u09AA\u09CD\u09B0\u09BF\u09B2", "\u09AE\u09C7", "\u099C\u09C1\u09A8",
            "\u099C\u09C1\u09B2\u09BE\u0987", "\u0986\u0997\u09B8\u09CD\u099F", "\u09B8\u09C7\u09AA\u09CD\u099F\u09C7\u09AE\u09CD\u09AC\u09B0", "\u0985\u0995\u09CD\u099F\u09CB\u09AC\u09B0", "\u09A8\u09AD\u09C7\u09AE\u09CD\u09AC\u09B0", "\u09A1\u09BF\u09B8\u09C7\u09AE\u09CD\u09AC\u09B0"};

    private Fmt() {
    }

    static String bn(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                sb.append((char) ('\u09E6' + (c - '0')));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    static String duration(long ms) {
        long min = ms / 60000L;
        if (min <= 0) {
            if (ms > 0) {
                return "<" + bn("1") + " \u09AE\u09BF";
            }
            return bn("0") + " \u09AE\u09BF";
        }
        long h = min / 60;
        long m = min % 60;
        if (h > 0 && m > 0) {
            return bn(h + " \u0998 " + m + " \u09AE\u09BF");
        }
        if (h > 0) {
            return bn(h + " \u0998");
        }
        return bn(m + " \u09AE\u09BF");
    }

    static String hoursShort(long ms) {
        if (ms <= 0) {
            return bn("0");
        }
        return bn(String.format(Locale.US, "%.1f", ms / 3600000.0)) + "\u0998";
    }

    static String percent(int p) {
        return bn(String.valueOf(p)) + "%";
    }

    static String dayShort(int dayOfWeek) {
        return DAY_SHORT[dayOfWeek - 1];
    }

    static String dateLong(Calendar c) {
        return DAY_LONG[c.get(Calendar.DAY_OF_WEEK) - 1] + ", "
                + bn(String.valueOf(c.get(Calendar.DAY_OF_MONTH))) + " "
                + MONTHS[c.get(Calendar.MONTH)];
    }
}
