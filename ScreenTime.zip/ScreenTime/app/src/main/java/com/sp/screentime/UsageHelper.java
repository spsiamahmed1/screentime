package com.sp.screentime;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Process;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

final class UsageHelper {

    private UsageHelper() {
    }

    static boolean hasPermission(Context c) {
        AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        if (ops == null) {
            return false;
        }
        int mode = ops.checkOpNoThrow("android:get_usage_stats",
                Process.myUid(), c.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /** start \u09A5\u09C7\u0995\u09C7 end \u09AA\u09B0\u09CD\u09AF\u09A8\u09CD\u09A4 \u09AA\u09CD\u09B0\u09A4\u09BF\u099F\u09BF \u0985\u09CD\u09AF\u09BE\u09AA \u0995\u09A4 \u09AE\u09BF\u09B2\u09BF\u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1 \u09B8\u09BE\u09AE\u09A8\u09C7 (foreground) \u099A\u09B2\u09C7\u099B\u09C7\u0964 */
    static Map<String, Long> usage(Context c, long start, long end) {
        Map<String, Long> totals = new HashMap<>();
        UsageStatsManager usm =
                (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) {
            return totals;
        }
        UsageEvents events = usm.queryEvents(start, end);
        if (events == null) {
            return totals;
        }

        Map<String, Long> fgStart = new HashMap<>();
        UsageEvents.Event e = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(e);
            String pkg = e.getPackageName();
            int type = e.getEventType();
            if (type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                fgStart.put(pkg, e.getTimeStamp());
            } else if (type == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                Long s = fgStart.remove(pkg);
                if (s != null) {
                    long d = e.getTimeStamp() - s;
                    if (d > 0) {
                        add(totals, pkg, d);
                    }
                }
            }
        }

        long cap = Math.min(end, System.currentTimeMillis());
        for (Map.Entry<String, Long> en : fgStart.entrySet()) {
            long d = cap - en.getValue();
            if (d > 0) {
                add(totals, en.getKey(), d);
            }
        }

        // \u09B6\u09C1\u09A7\u09C1 \u09AF\u09C7\u09B8\u09AC \u0985\u09CD\u09AF\u09BE\u09AA \u09AB\u09CB\u09A8\u09C7\u09B0 \u09B2\u099E\u09CD\u099A\u09BE\u09B0\u09C7 \u09A6\u09C7\u0996\u09BE \u09AF\u09BE\u09AF\u09BC \u09B8\u09C7\u0997\u09C1\u09B2\u09CB \u09B0\u09BE\u0996\u09BF
        PackageManager pm = c.getPackageManager();
        Iterator<Map.Entry<String, Long>> it = totals.entrySet().iterator();
        while (it.hasNext()) {
            String pkg = it.next().getKey();
            if (pm.getLaunchIntentForPackage(pkg) == null) {
                it.remove();
            }
        }
        return totals;
    }

    private static void add(Map<String, Long> map, String key, long value) {
        Long old = map.get(key);
        map.put(key, (old == null ? 0L : old) + value);
    }
}
